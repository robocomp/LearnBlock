<a name="Inicio"></a>

# Como utilizar Learnblock

En este capítulo aprenderás a localizar las diferentes utilidades disponibles en Learnblock, así como a utilizar dichas utilidades, desde la creación de un proyecto sencillo haciendo la utilización la programación con bloques.

Tambíen se exponén los pasos a serguir para crear he utilizar una librería de bloques.

A continuacón se muestra una tabla de contenido.
 
> [1. Programación con bloques](<hidepath>/ES/2.%20Como%20utilizar%20Learnblock/1.%20Programaci%C3%B3n%20con%20bloques/README.html)

> > [1.1. Bloques disponibles.md](<hidepath>/ES/2.%20Como%20utilizar%20Learnblock/1.%20Programaci%C3%B3n%20con%20bloques/1.%20Bloques%20disponibles.html)

> > [1.2. Programación Secuencial.md](<hidepath>/ES/2.%20Como%20utilizar%20Learnblock/1.%20Programaci%C3%B3n%20con%20bloques/2.%20Programaci%C3%B3n%20Secuencial.html)

> > [1.3. Programación con Eventos.md](<hidepath>/ES/2.%20Como%20utilizar%20Learnblock/1.%20Programaci%C3%B3n%20con%20bloques/3.%20Programaci%C3%B3n%20con%20Eventos.html)

> [2. Programación con texto](<hidepath>/ES/2.%20Como%20utilizar%20Learnblock/2.%20Programaci%C3%B3n%20con%20texto/README.html)

> >[2.1. Funciones disponibles](<hidepath>/ES/2.%20Como%20utilizar%20Learnblock/2.%20Programaci%C3%B3n%20con%20texto/1.%20Funciones%20disponibles.html)

> >[2.2. Programación Secuencial](<hidepath>/ES/2.%20Como%20utilizar%20Learnblock/2.%20Programaci%C3%B3n%20con%20texto/2.%20Programaci%C3%B3n%20Secuencial.html)

> >[2.3. Programación con Eventos](<hidepath>/ES/2.%20Como%20utilizar%20Learnblock/2.%20Programaci%C3%B3n%20con%20texto/3.%20Programaci%C3%B3n%20con%20Eventos.html)

> [3. Como utilizar el simulador](<hidepath>/ES/2.%20Como%20utilizar%20Learnblock/3.%20Como%20utilizar%20el%20simulador.html)

> [4. Crear una librería](<hidepath>/ES/2.%20Como%20utilizar%20Learnblock/4.%20Crear%20una%20librer%C3%ADa.html)

> [5. Utilizar una librería](<hidepath>/ES/2.%20Como%20utilizar%20Learnblock/5.%20Utilizar%20una%20librer%C3%ADa.html)


[Inicio^](#Inicio)

[<Anterior]()
[Siguiente>]()