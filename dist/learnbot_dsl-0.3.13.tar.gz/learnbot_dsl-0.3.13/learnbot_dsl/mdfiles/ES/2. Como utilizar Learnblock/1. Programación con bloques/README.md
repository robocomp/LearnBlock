<a name="Inicio"></a>

# Programación con Bloques

Learnblock ofrece la posibilidad de crear programas haciendo uso de programación visual mediante bloques.

En este capítulo veremos donde se localizan los diferentes bloques, que bloques disponibles y 
los dos tipos de programación que se pueden utilizar.

A continuación se muestra una tabla de contenidos:

> [1. Bloques disponibles.md](<hidepath>/ES/2.%20Como%20utilizar%20Learnblock/1.%20Programaci%C3%B3n%20con%20bloques/1.%20Bloques%20disponibles.html)

> [2. Programación Secuencial.md](<hidepath>/ES/2.%20Como%20utilizar%20Learnblock/1.%20Programaci%C3%B3n%20con%20bloques/2.%20Programaci%C3%B3n%20Secuencial.html)

> [3. Programación con Eventos.md](<hidepath>/ES/2.%20Como%20utilizar%20Learnblock/1.%20Programaci%C3%B3n%20con%20bloques/3.%20Programaci%C3%B3n%20con%20Eventos.html)


[Inicio^](#Inicio)

[<Anterior]()
[Siguiente>]()