
def is_image(lbot, id):
    lbot.lookingLabel(id)
