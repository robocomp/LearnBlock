from __future__ import print_function, absolute_import

def get_image(lbot):
	frame = lbot.getImage()
	return frame
