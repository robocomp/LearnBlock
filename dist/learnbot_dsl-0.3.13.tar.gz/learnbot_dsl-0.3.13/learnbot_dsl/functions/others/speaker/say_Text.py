

def say_Text(lbot, _text):
    lbot.speakText(_text)