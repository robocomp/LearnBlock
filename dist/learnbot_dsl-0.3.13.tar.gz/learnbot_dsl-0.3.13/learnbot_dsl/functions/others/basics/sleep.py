
import time

def sleep(lbot, seconds):
    time.sleep(seconds)
