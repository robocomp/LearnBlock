from learnbot_dsl.Clients.Devices import Emotions


def expressJoy(lbot):
    lbot.express(Emotions.Joy)
