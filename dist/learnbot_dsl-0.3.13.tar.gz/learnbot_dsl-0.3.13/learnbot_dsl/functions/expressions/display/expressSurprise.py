from learnbot_dsl.Clients.Devices import Emotions

def expressSurprise(lbot):
    lbot.express(Emotions.Surprise)
