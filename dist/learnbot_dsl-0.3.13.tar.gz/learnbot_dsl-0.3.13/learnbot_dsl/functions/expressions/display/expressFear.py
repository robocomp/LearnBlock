from learnbot_dsl.Clients.Devices import Emotions


def expressFear(lbot):
    lbot.express(Emotions.Fear)
