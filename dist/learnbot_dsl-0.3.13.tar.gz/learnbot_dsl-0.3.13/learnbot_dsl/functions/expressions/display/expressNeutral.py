from learnbot_dsl.Clients.Devices import Emotions

def expressNeutral(lbot):
    lbot.express(Emotions.Neutral)
