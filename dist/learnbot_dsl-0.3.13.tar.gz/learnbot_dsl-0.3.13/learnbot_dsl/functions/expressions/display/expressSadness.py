from learnbot_dsl.Clients.Devices import Emotions

def expressSadness(lbot):
    lbot.express(Emotions.Sadness)
