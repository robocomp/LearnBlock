import time


def move_straight(lbot, advSpeed=40, verbose=False):
	lbot.setBaseSpeed(advSpeed, 0)

