from __future__ import division, print_function
import time, math

def turn_left(lbot, rotSpeed=-0.3):
	lbot.setBaseSpeed(0, rotSpeed)


