

def look_up(lbot):
    lbot.setJointAngle("CAMERA",0.6000000238)
