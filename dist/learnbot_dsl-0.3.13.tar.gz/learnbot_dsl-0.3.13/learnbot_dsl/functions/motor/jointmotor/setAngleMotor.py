

def setAngleMotor(lbot, _key, angle):
    lbot.setJointAngle(_key, angle)
