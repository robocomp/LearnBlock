

def setAngleCamera(lbot,angle):
    lbot.setJointAngle("CAMERA", angle)
