

def look_front(lbot):
    lbot.setJointAngle("CAMERA",0)
