

def look_floor(lbot):
    lbot.setJointAngle("CAMERA",-0.6000000238)
