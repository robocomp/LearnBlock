
def is_turning_left(lbot):
	return lbot.getRot() < 0 and lbot.getAdv() is 0
