def get_pose(lbot):
	x, y, alpha = lbot.getPose()
	return x, y, alpha
