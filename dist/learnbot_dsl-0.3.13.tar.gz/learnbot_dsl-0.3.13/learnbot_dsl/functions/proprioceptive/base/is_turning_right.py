
def is_turning_right(lbot):
	return lbot.getRot() > 0 and lbot.getAdv() is 0
