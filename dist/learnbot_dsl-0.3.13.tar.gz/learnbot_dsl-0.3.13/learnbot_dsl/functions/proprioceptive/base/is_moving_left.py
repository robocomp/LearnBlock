
def is_moving_left(lbot):
	return lbot.getRot() < 0 and lbot.getAdv() > 0
