
def is_turning(lbot):
	return lbot.getRot() is not 0 and lbot.getAdv() is 0
