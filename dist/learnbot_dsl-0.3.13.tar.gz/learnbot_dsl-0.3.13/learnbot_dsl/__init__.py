from __future__ import print_function, absolute_import
import os, sys

path = os.path.dirname(os.path.realpath(__file__))
__version__ = '0.3.13'

PATHINTERFACES = os.path.join(path, "interfaces")
PATHCLIENT = os.path.join(path, "Clients")
