#!/usr/bin/env python
# -*- coding: utf-8 -*-
from __future__ import print_function, absolute_import
import os

path = os.path.dirname(os.path.realpath(__file__))
pathImgBlocks = os.path.join(path, 'blocks')
pathBlocks = pathImgBlocks
pathConfig = path







