
[![Donate](https://img.shields.io/badge/Donate-PayPal-green.svg)](https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=N3VAYG9VP8S4L)

---

# _We suggest using the version-2 branch_
[Learnbot v 2.0](http://robocomp.org)
===============================
LearnBot is a social low cost robot that has been designed in to  the  area  of  educational  robotics  for  promoting  the  development of  computational  thinking  in  diferent  educational  stages,  specically through the learning of the Python language. It has being entirely built using a robotics framework developed by our Robotic Laboratory.

But Learnbot is part of a more ambitious ecosystem, Learnblock, which is being  created  as  a  facilitator  environment  to  encourage  current  teacher swith out programming knowledge to learn the basics of programming, it is a IDE similar to Scrach, at least into a level where they can introduce their students into the digital world.

# Project aims

The mains aims of the project are the follows:

* To teach to kids:
    * Programing.
    * Math.
    * Logic.
    * Emotions.
    * Robotics.
    * Languages.
    * Physics.
    

# Manuals Learnbot!
1. [Documentation](../../wiki)
2. Enjoy!

# Citting
1. Code2bot: Una propuesta de comunidad de aprendizaje de la programación basada en robots. JM Haut, N García, M Paoletti, P Bustos. XXIII Jornadas de Tecnologías Educativas, JUTE. Badajoz, 2015.

# Publications
1. Code2bot: Una propuesta de comunidad de aprendizaje de la programación basada en robots. JM Haut, N García, M Paoletti, P Bustos. XXIII Jornadas de Tecnologías Educativas, JUTE. Badajoz, 2015.
2. Code2Bot, a social robot for the classroom. JM Haut, P Bustos, M Paoletti, N Garcia. Conference of the Spanish Association for Artificial Intelligence, CAEPIA. Albacete, 2015.
3. LearnBot: aprendizaje colaborativo con robots. E Paoletti, M Paoletti, JM Haut, N García, P Bustos. Workshop: Investigar en Ciencias. Badajoz, 2016.
4. LearnBot: aprendiendo el pasado con nuevas tecnologías. E Paoletti, M Paoletti, JM Haut, N García, P Bustos. Workshop: Investigar en Ciencias. Badajoz, 2016.


# Contributing
Thanks for your interest in contributing code!
If you find an error or some improvement, I'd appreciate you told me. Please, use [this template](https://github.com/robocomp/learnbot/blob/91275d466a7d4269f8451047b3928c9c65d3f363/PULL_REQUEST_TEMPLATE)

---------------------------------------------------------------------
Drop comments and ask questions in:

- https://groups.google.com/forum/?hl=es#!forum/robocomp-dev
- https://gitter.im/robocomp/robocomp

Please, report any bugs to pbustos@unex.es



